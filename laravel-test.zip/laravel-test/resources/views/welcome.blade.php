<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>Test Application</title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,600&display=swap" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>

<body>
    <div class="container mt-5">
        <h1>Customer Form</h1>
        @if (session('success'))
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                {{ session('success') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        @endif
        @if (session('duplicate'))
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                {{ session('duplicate') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        @endif
        <form action="" method="post">
            @csrf
            <div class="mb-3">
                <label for="exampleFormControlInput1" class="form-label">Name</label>
                <input type="text" class="form-control" placeholder="Customer name" name="name" value="{{old('name')}}">
                <span class="text-danger">@error('name'){{$message}}@enderror</span>
            </div>
            <div class="mb-3">
                <label for="exampleFormControlInput1" class="form-label">Email</label>
                <input type="email" class="form-control" placeholder="name@example.com" name="email" id="email" value="{{old('email')}}">
                <span class="text-danger" id="email_duplicate"></span>
                <span class="text-danger">@error('email'){{$message}}@enderror</span>
            </div>
            <div class="mb-3">
                <label for="exampleFormControlInput1" class="form-label">Phone</label>
                <input type="number" class="form-control" placeholder="Contact number" name="phone" id="phone" value="{{old('phone')}}">
                <span class="text-danger" id="phone_duplicate"></span>
                <span class="text-danger">@error('phone'){{$message}}@enderror</span>
            </div>

            <div class="mb-3">
                <label for="exampleFormControlInput1" class="form-label">Address</label>
                <textarea name="address" class="form-control" placeholder="Enter your full address">{{old('address')}}</textarea>
                <span class="text-danger">@error('address'){{$message}}@enderror</span>
            </div>

            <div class="mb-3">
                <label for="exampleFormControlInput1" class="form-label">Pincode</label>
                <input type="number" class="form-control" placeholder="Pincode" name="pincode" value="{{old('pincode')}}">
                <span class="text-danger">@error('pincode'){{$message}}@enderror</span>
            </div>

            <div class="">
                <button type="submit" name="submit" value="submit" id="submit" class="btn btn-success">Submit</button>
            </div>
        </form>

        <table class="table">
                <thead>
                    <tr>
                        <th>Sl No.</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Mobile</th>
                        <th>Address</th>
                        <th>Pincode</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i=0;  ?>
                    @foreach($datas as $data)
                    <tr>
                        <td>{{++$i}}</td>
                        <td>{{$data->name}}</td>
                        <td>{{$data->email}}</td>
                        <td>{{$data->phone}}</td>
                        <td>
                            <?php 
$dt=DB::select("select * from customeraddresses where customer_id='".$data->id."' ");
if($dt != null){
    echo $dt[0]->address;
}else{
    echo "No data found";
}
                             ?>
                        </td>
                        <td>
                              <?php 
$dt=DB::select("select * from customeraddresses where customer_id='".$data->id."' ");
if($dt != null){
    echo $dt[0]->pincode;
}else{
    echo "No data found";
}
                             ?>

                        </td>
                    </tr>
                    @endforeach
                </tbody>
            
        </table>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script> -->

    <script>
        $(document).ready(function(){
            ////phone duplicate
            $('#phone').keyup(function(){
                var phone=$(this).val();
                $.ajax({
                    url:"{{url('/')}}/check_phone",
                    type: "POST",
                    data:{phone: phone},
                    headers: {
                         'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                     },
                    success:function(response){
                        if(response.exists){
                            $('#phone_duplicate').text("This mobile number is already exists");
                        }
                    }
                });
            });

            ///email duplicate
            $('#email').keyup(function(){
                var email=$(this).val();
                $.ajax({
                    url:"{{url('/')}}/check_email",
                    type: "POST",
                    data:{email: email},
                    success:function(response){
                        if(response.exists){
                            $('#email_duplicate').text("This email id is already exists");
                        }
                    }
                });
            });
        });
    </script>
</body>

</html>
