<?php

namespace App\Http\Controllers;

use App\Models\Customer;
use App\Models\Customeraddress;
use Illuminate\Http\Request;

class CustomerController extends Controller
{
    public function add_details(Request $request){
        if(isset($request->submit)){

            $email=$request->email;
           // print_r($email); exit();
            $phone=$request->phone;
                $request->validate([
                    'name'=>'required|min:3',
                    'email'=>'required|email|unique:customers',
                    'phone'=>'required|unique:customers',
                    'pincode'=>'required|digits:6',
                    'address'=>'required',
                ],
                [
                    'name.required'=>'Please enter your name',
                    'name.min'=>'name should be minimum 3 letter',
                    'email.required'=>'Please enter email',
                    'email.unique'=>'This mail id is already exists',
                    'email.email'=>'Please enter a valid email',
                    'phone.required'=>'Please enter your mobile number',
                    'phone.digits'=>'Please enter 10 digit mobile number',
                    'pincode.digits'=>'Please enter 6 digit pincode'

                ]
            );
            //     Customer::create([
            //     'name'=>$request->name,
            //     'email'=>$email,
            //     'phone'=>$phone,
            // ]);
                $add=new Customer();
                $add->name=$request->name;
                $add->email=$email;
                $add->phone=$phone;
                $add->save();
                $customer_id=$add->id;
                //print_r($customer_id); exit();
                if($customer_id != null){
                    $address=new Customeraddress();
                    $address->customer_id=$customer_id;
                    $address->address=$request->address;
                    $address->pincode=$request->pincode;
                    $address->save();
                    return back()->with('success','Customer added successfully');
                }
        }
        $datas=Customer::orderby('id')->get();
        return view('welcome', compact('datas'));
    }

    public function check_phone(Request $request){
        $phone=$request->phone;
        $phone_count=Customer::where('phone', $phone)->count();
        if($phone_count > 0){
            return response()->json(['exists'=>true]);
        }else{
            return response()->json(['exists'=>false]);
        }
    }

    public function check_email(Request $request){
        $email=$request->email;
        $email_count=Customer::where('email', $email)->count();
        if($email_count > 0){
            return response()->json(['exists'=>true]);
        }else{
            return response()->json(['exists'=>false]);
        }

    }
}
